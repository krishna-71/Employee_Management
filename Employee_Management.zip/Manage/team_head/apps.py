from django.apps import AppConfig


class TeamHeadConfig(AppConfig):
    name = 'team_head'
